//
//  Square.swift
//  chess-schweiter
//
//  Created by SCHWEITER JOHN S on 5/3/16.
//  Copyright © 2016 example. All rights reserved.
//

import Foundation
import SpriteKit

class Square {
    
    let position: CGPoint
    var piece: Piece?
    var piecesWhichCheck: Array<Piece>
    init(position: CGPoint) {
        self.position = position
        self.piecesWhichCheck = []
    }
    
}