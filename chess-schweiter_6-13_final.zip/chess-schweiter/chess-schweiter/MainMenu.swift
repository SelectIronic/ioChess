//
//  MainMenu.swift
//  chess-schweiter
//
//  Created by SCHWEITER JOHN S on 4/12/16.
//  Copyright © 2016 example. All rights reserved.
//

import Foundation
import SpriteKit

class MainMenu: SKScene {
    
    var playButton : SKSpriteNode?
    var optionsButton : SKSpriteNode?
    override func didMoveToView(view: SKView) {
        playButton = self.childNodeWithName("PLAY") as! SKSpriteNode!
        optionsButton = self.childNodeWithName("OPTIONS") as! SKSpriteNode!
    }
    override func touchesBegan(touches: Set<UITouch>, withEvent event: UIEvent?) {
        for touch in touches {
            let location = touch.locationInNode(self)
            print(location.x, location.y)
            print(nodeAtPoint(location).name)
            if(nodeAtPoint(location) == optionsButton) {
                print("optionsButton clicked")
                let optionScene = OptionsMenu(fileNamed: "OptionsMenu")
                
                optionScene?.scaleMode = .AspectFit
                self.view?.presentScene(optionScene!, transition: SKTransition.pushWithDirection(SKTransitionDirection.Left, duration: 1))
            }
            if(nodeAtPoint(location) == playButton) {
                print("playButton clicked")
                let gameScene = GameScene(fileNamed: "GameScene")
                
                gameScene?.scaleMode = .AspectFit
                self.view?.presentScene(gameScene!, transition: SKTransition.pushWithDirection(SKTransitionDirection.Left, duration: 1))
            }
        }
    }
}