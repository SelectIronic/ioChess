//
//  Piece.swift
//  chess-schweiter
//
//  Created by SCHWEITER JOHN S on 4/18/16.
//  Copyright © 2016 example. All rights reserved.
//

import Foundation
import SpriteKit

class Piece: SKSpriteNode {
    var pieceType : String
    var pieceColor : String
    var availableMoves : Array<CGPoint>
    var hasMoved : Bool
    var piecesWhichCheck : Array<Piece>
    var piecesWhichProtect : Array<Piece>
    var myScene : SKScene
    
    init(pieceType: String, pieceColor: String, position: CGPoint, myScene: SKScene) {
        let texture = SKTexture(imageNamed: "\(pieceType)_\(pieceColor).png")
        self.pieceType = pieceType
        self.pieceColor = pieceColor
        self.availableMoves = []
        self.hasMoved = false
        piecesWhichCheck = []
        piecesWhichProtect = []
        self.myScene = myScene
        super.init(texture: texture, color: UIColor.clearColor(), size: texture.size())
        self.position = position
        myScene.addChild(self)
    }
    
    required init?(coder aDecoder: NSCoder) {
        self.pieceType = ""
        self.pieceColor = ""
        self.availableMoves = []
        self.hasMoved = false
        piecesWhichCheck = []
        piecesWhichProtect = []
        self.myScene = SKScene()
        super.init( coder: aDecoder )
    }
    
    func pieceCanMoveToSquare( location: CGPoint ) -> Bool {
        var moveOK = false
        moveOK = self.availableMoves.contains(location)
        return moveOK
    }
    
    func moveIsLegal( move : CGPoint ) -> Bool {
        return (move.x >= -336 && move.x <= 336 && move.y >= -336 && move.y <= 336 && move != self.position)
    }
    
    func movementPattern() -> Array<CGPoint> {
        var pattern = Array<CGPoint>()
        let myX = self.position.x
        let myY = self.position.y
        //[N, NE, E, SE, S, SW, W, NW]
        var compass = Array<Int>()
        
        switch pieceType {
            case "king":
                compass = [1, 1, 1, 1, 1, 1, 1, 1]
        case "queen":
            compass = [7, 7, 7, 7, 7, 7, 7, 7]
        case "bishop":
            compass = [0, 7, 0, 7, 0, 7, 0, 7]
        case "knight":
            compass = [0, 0, 0, 0, 0, 0, 0, 0]
        case "rook":
            compass = [7, 0, 7, 0, 7, 0, 7, 0]
        case "pawn":
            compass = [0, 0, 0, 0, 0, 0, 0, 0]
        default:
            print("What Type of Piece is this?")
        }
        let compassUnitVectors = [[0, 1], [1, 1], [1, 0], [1, -1], [0, -1], [-1, -1], [-1, 0], [-1, 1]]
        
        for directionIndex in 0...7 {
            var pieceHit = false
            for i in 1..<(compass[directionIndex] + 1) {
                let nextPoint = CGPoint(x: myX + CGFloat(96 * i * compassUnitVectors[directionIndex][0]), y: myY + CGFloat(96 * i * compassUnitVectors[directionIndex][1]))
                if (nextPoint.x >= -336 && nextPoint.x <= 336 && nextPoint.y >= -336 && nextPoint.y <= 336 && nextPoint != self.position) {
                    if !pieceHit {
                        if let piece = myScene.nodeAtPoint(nextPoint) as? Piece {
                            pieceHit = true
                            if piece.pieceColor == self.pieceColor {
                                piece.piecesWhichProtect.append(self)
                            } else {
                                piece.piecesWhichCheck.append(self)
                                if moveIsLegal(nextPoint) { pattern.append(nextPoint) }
                            }
                        } else {
                            pieceHit = false
                            if moveIsLegal(nextPoint) { pattern.append(nextPoint) }
                        }
                    }
                }
                
            }
        }
        return pattern
    }
    
    func setAvailableMoves() {
        
        let myX = self.position.x
        let myY = self.position.y
        switch pieceType {
            case "king":
                self.availableMoves.appendContentsOf(movementPattern())
            case "queen":
                self.availableMoves.appendContentsOf(movementPattern())
            case "bishop":
                self.availableMoves.appendContentsOf(movementPattern())
            case "knight":
                //special pattern
                let knight_pattern = [
                    CGPoint(x: myX + 96, y: myY + 192),
                    CGPoint(x: myX + 192, y: myY + 96),
                    CGPoint(x: myX + 192, y: myY - 96),
                    CGPoint(x: myX + 96, y: myY - 192),
                    CGPoint(x: myX - 96, y: myY - 192),
                    CGPoint(x: myX - 192, y: myY - 96),
                    CGPoint(x: myX - 192, y: myY + 96),
                    CGPoint(x: myX - 96, y: myY + 192)
                ]
                for move in knight_pattern {
                    var isLegal = true
                    if let piece = myScene.nodeAtPoint(move) as? Piece {
                        if piece.pieceColor == self.pieceColor {
                            piece.piecesWhichProtect.append(self)
                            isLegal = false
                        } else {
                            piece.piecesWhichCheck.append(self)
                        }
                    }
                    if isLegal && moveIsLegal(move) { self.availableMoves.append(move) }
                }
            case "rook":
                self.availableMoves.appendContentsOf(movementPattern())
            case "pawn":
                //special pattern
                //if <square> contains an enemy
                var forward = CGFloat(1)
                forward = pieceColor == "white" ? 1 : -1
                
                if moveIsLegal( CGPoint(x: myX + 96, y: myY + 96 * forward) ) {
                    if let piece = myScene.nodeAtPoint(CGPoint(x: myX + 96, y: myY + 96 * forward)) as? Piece {
                        if piece.pieceColor != self.pieceColor {
                            self.availableMoves.append( CGPoint(x: myX + 96, y: myY + 96 * forward) )
                            piece.piecesWhichCheck.append(self)
                        } else {
                            piece.piecesWhichProtect.append(self)
                        }
                    }
                }
                
                if moveIsLegal( CGPoint(x: myX - 96, y: myY + 96 * forward) ) {
                    if let piece = myScene.nodeAtPoint(CGPoint(x: myX - 96, y: myY + 96 * forward)) as? Piece {
                        if piece.pieceColor != self.pieceColor {
                            self.availableMoves.append( CGPoint(x: myX - 96, y: myY + 96 * forward) )
                            piece.piecesWhichCheck.append(self)
                        } else {
                            piece.piecesWhichProtect.append(self)
                        }
                    }
                }
                
                //if <square> is empty
                if moveIsLegal( CGPoint(x: myX, y: myY + 96 * forward) ) && !myScene.nodeAtPoint(CGPoint(x: myX, y: myY + 96 * forward)).isKindOfClass(Piece) {
                    self.availableMoves.append( CGPoint(x: myX, y: myY + 96 * forward) )
                    //if !self.hasMoved
                    if moveIsLegal( CGPoint(x: myX, y: myY + 192 * forward) ) && !myScene.nodeAtPoint(CGPoint(x: myX, y: myY + 192 * forward)).isKindOfClass(Piece) && !self.hasMoved {
                        self.availableMoves.append( CGPoint(x: myX, y: myY + 192 * forward) )
                    }
                }
            
            
        default:
            print("I don't know what type of piece this is: \(self.pieceType)")
        }
        //print("Name: \(self.name); Moves: \(self.availableMoves)")
     }
    
//    func movePieceToSquare(square: CGPoint) {
//        print(square)
//        if pieceCanMoveToSquare(square) {
//            self.runAction(SKAction.moveTo(square, duration: 0.5))
//            self.hasMoved = true
//        }
//    }
    

}