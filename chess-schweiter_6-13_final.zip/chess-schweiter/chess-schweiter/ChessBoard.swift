//
//  ChessBoard.swift
//  chess-schweiter
//
//  Created by SCHWEITER JOHN S on 4/18/16.
//  Copyright © 2016 example. All rights reserved.
//

import Foundation
import SpriteKit

class ChessBoard {
//    let rank : [String: Int] = ["1": -336, "2": -240, "3": -144, "4": -48, "5": 48, "6": 144, "7": 240, "8": 336]
//    let file : [String: Int] = ["a": -336, "b": -240, "c": -144, "d": -48, "e": 48, "f": 144, "g": 240, "h": 336]
//    var a1 = Square(CGPoint(x: -336, y: -336)

    func squareAtPoint(location: CGPoint) -> Square {
//        return (squares[ Int((((location.x + 336) - ((location.x + 336) % 96)) / 96)) ][ Int((((location.y + 336) - ((location.x + 336) % 96)) / 96)) ])
        return (squares[ axisToIndex(location.x) ][ axisToIndex(location.y) ])
    }
    
    func axisToIndex(axis: CGFloat) -> Int {
        return Int((((axis + 336) - ((axis + 336) % 96)) / 96))
    }
    
    func setPiecesWhichCheck() {
        for file in squares {
            for square in file {
                square.piecesWhichCheck.removeAll()
            }
        }
        for file in squares {
            for square in file {
                if let piece = square.piece {
                    for move in piece.availableMoves {
                        squares[axisToIndex(move.x)][axisToIndex(move.y)].piecesWhichCheck.append(piece)
                    }
                }
            }
        }
    }
    
    func makeCopyOfSquares() -> Array<Array<Square>> {
        var copyOfSquares: Array<Array<Square>>
        copyOfSquares = []
        var fileIndex = 0
        for file in squares {
            
            copyOfSquares.append([])
            for oldSquare in file {
                let newSquare = Square(position: oldSquare.position)
                if oldSquare.piece != nil {
                    newSquare.piece = Piece(pieceType: oldSquare.piece!.pieceType, pieceColor: oldSquare.piece!.pieceColor, position: oldSquare.piece!.position, myScene: oldSquare.piece!.myScene)
                }
                
                copyOfSquares[fileIndex].append(newSquare)
            }
            fileIndex += 1
        }
        return copyOfSquares
    }
    
    
    //NOT SURE WHAT TO DO FOR PROMOTION
    func canMove(pieceLocation: CGPoint, destination: CGPoint, special: String?) -> Bool {
        var canMove = true
        
        let pieceLocation_x = axisToIndex(pieceLocation.x)
        let pieceLocation_y = axisToIndex(pieceLocation.y)
        let destination_x = axisToIndex(destination.x)
        let destination_y = axisToIndex(destination.y)
        
        let activePieceColor = squares[pieceLocation_x][pieceLocation_y].piece!.pieceColor
        var endangeredPiece : Piece?
        var activePieceKing : Piece!
        for file in squares {
            for square in file {
                if square.piece != nil {
                    if square.piece?.pieceColor == activePieceColor && square.piece?.pieceType == "king" {activePieceKing = square.piece!}
                }
            }
        }
        activePieceKing.piecesWhichCheck.removeAll()
        
        let forward = activePieceColor == "white" ? 1 : -1
        
        if squares[destination_x][destination_y].piece != nil {
            if activePieceColor == squares[destination_x][destination_y].piece!.pieceColor || special == "castle_kingside" {
                canMove = false
            } else {
                endangeredPiece = squares[destination_x][destination_y].piece!
                endangeredPiece!.position = CGPoint(x: 672, y: 144)
                //print(endangeredPiece)
                squares[destination_x][destination_y].piece = nil
                //print(endangeredPiece)
            }
        }
        if special == "castle_kingside" {
            if squares[destination_x - 1][destination_y].piece != nil {canMove = false}
        }
        
        if canMove {
            //swap the piece references of pieceLocation and destination
            ( squares[destination_x][destination_y].piece,
                squares[pieceLocation_x][pieceLocation_y].piece ) =
                ( squares[pieceLocation_x][pieceLocation_y].piece,
                    squares[destination_x][destination_y].piece )
                    squares[destination_x][destination_y].piece!.position = destination
            
            if special == "castle_kingside" {
                ( squares[destination_x + 1][destination_y].piece,
                    squares[pieceLocation_x + 1][pieceLocation_y].piece ) =
                    ( squares[pieceLocation_x + 1][pieceLocation_y].piece,
                        squares[destination_x + 1][destination_y].piece )
                squares[destination_x - 1][destination_y].piece!.position = CGPoint(x: destination.x - 96, y: destination.y)
            }
            
            
            for file in squares {
                for square in file {
                    if square.piece != nil {
                        square.piece?.setAvailableMoves()
                    }
                }
            }
            
            if activePieceKing.piecesWhichCheck.count > 0 {
                canMove = false
            }
            
//            if !canMove {
                //undo move
                ( squares[destination_x][destination_y].piece,
                    squares[pieceLocation_x][pieceLocation_y].piece ) =
                    ( squares[pieceLocation_x][pieceLocation_y].piece,
                        squares[destination_x][destination_y].piece )
                
                if special == "castle_kingside" {
                    ( squares[destination_x + 1][destination_y].piece,
                        squares[pieceLocation_x + 1][pieceLocation_y].piece ) =
                        ( squares[pieceLocation_x + 1][pieceLocation_y].piece,
                            squares[destination_x + 1][destination_y].piece )
                    squares[destination_x + 1][destination_y].piece!.position = CGPoint(x: destination.x + 96, y: destination.y)
                }
                
                //en_passant exception for capturing a piece not on the destination
                if special == "en_passant" {
                    squares[destination_x][destination_y - (1 * forward)].piece = endangeredPiece
                    endangeredPiece!.position = CGPoint(x: destination.x, y: destination.y - CGFloat(96 * forward))
                } else {
                    squares[destination_x][destination_y].piece = endangeredPiece
                    endangeredPiece?.position = destination
                }
                
                squares[pieceLocation_x][pieceLocation_y].piece!.position = pieceLocation
//            } else {
//                squares[destination_x][destination_y].piece!.position = pieceLocation
//            }
        }
        
        for file in squares {
            for square in file {
                if square.piece != nil {
                    square.piece!.availableMoves.removeAll()
                    square.piece!.piecesWhichCheck.removeAll()
                    square.piece!.piecesWhichProtect.removeAll()
                }
            }
        }
        
        for file in squares {
            for square in file {
                if square.piece != nil {
                    square.piece!.setAvailableMoves()
                }
            }
        }
        return canMove
    }
    
    
    var squares = [
        [ Square(position: CGPoint(x: -336, y: -336)), Square(position: CGPoint(x: -336, y: -240)), Square(position: CGPoint(x: -336, y: -144)), Square(position: CGPoint(x: -336, y: -48)), Square(position: CGPoint(x: -336, y: 48)), Square(position: CGPoint(x: -336, y: 144)), Square(position: CGPoint(x: -336, y: 240)), Square(position: CGPoint(x: -336, y: 336)) ],
        [ Square(position: CGPoint(x: -240, y: -336)), Square(position: CGPoint(x: -240, y: -240)), Square(position: CGPoint(x: -240, y: -144)), Square(position: CGPoint(x: -240, y: -48)), Square(position: CGPoint(x: -240, y: 48)), Square(position: CGPoint(x: -240, y: 144)), Square(position: CGPoint(x: -240, y: 240)), Square(position: CGPoint(x: -240, y: 336)) ],
        [ Square(position: CGPoint(x: -144, y: -336)), Square(position: CGPoint(x: -144, y: -240)), Square(position: CGPoint(x: -144, y: -144)), Square(position: CGPoint(x: -144, y: -48)), Square(position: CGPoint(x: -144, y: 48)), Square(position: CGPoint(x: -144, y: 144)), Square(position: CGPoint(x: -144, y: 240)), Square(position: CGPoint(x: -144, y: 336)) ],
        [ Square(position: CGPoint(x: -48, y: -336)), Square(position: CGPoint(x: -48, y: -240)), Square(position: CGPoint(x: -48, y: -144)), Square(position: CGPoint(x: -48, y: -48)), Square(position: CGPoint(x: -48, y: 48)), Square(position: CGPoint(x: -48, y: 144)), Square(position: CGPoint(x: -48, y: 240)), Square(position: CGPoint(x: -48, y: 336)) ],
        [ Square(position: CGPoint(x: 48, y: -336)), Square(position: CGPoint(x: 48, y: -240)), Square(position: CGPoint(x: 48, y: -144)), Square(position: CGPoint(x: 48, y: -48)), Square(position: CGPoint(x: 48, y: 48)), Square(position: CGPoint(x: 48, y: 144)), Square(position: CGPoint(x: 48, y: 240)), Square(position: CGPoint(x: 48, y: 336)) ],
        [ Square(position: CGPoint(x: 144, y: -336)), Square(position: CGPoint(x: 144, y: -240)), Square(position: CGPoint(x: 144, y: -144)), Square(position: CGPoint(x: 144, y: -48)), Square(position: CGPoint(x: 144, y: 48)), Square(position: CGPoint(x: 144, y: 144)), Square(position: CGPoint(x: 144, y: 240)), Square(position: CGPoint(x: 144, y: 336)) ],
        [ Square(position: CGPoint(x: 240, y: -336)), Square(position: CGPoint(x: 240, y: -240)), Square(position: CGPoint(x: 240, y: -144)), Square(position: CGPoint(x: 240, y: -48)), Square(position: CGPoint(x: 240, y: 48)), Square(position: CGPoint(x: 240, y: 144)), Square(position: CGPoint(x: 240, y: 240)), Square(position: CGPoint(x: 240, y: 336)) ],
        [ Square(position: CGPoint(x: 336, y: -336)), Square(position: CGPoint(x: 336, y: -240)), Square(position: CGPoint(x: 336, y: -144)), Square(position: CGPoint(x: 336, y: -48)), Square(position: CGPoint(x: 336, y: 48)), Square(position: CGPoint(x: 336, y: 144)), Square(position: CGPoint(x: 336, y: 240)), Square(position: CGPoint(x: 336, y: 336)) ]
    ]
    
}





//For Reference

//En passant:
//When a pawn advances two squares from its starting position and there is an opponent's pawn on an adjacent file next to its destination square, 
//then the opponent's pawn can capture it en passant (in passing), and move to the square the pawn passed over.
//However, this can only be done on the very next move, otherwise the right to do so is forfeit. 
//For example, if the black pawn has just advanced two squares from g7 (initial starting position) to g5, 
//then the white pawn on f5 may take it via en passant on g6 (but only on white's next move).


//var squares = [
//    [//A
//        Square(position: CGPoint(x: -336, y: -336)),
//        Square(position: CGPoint(x: -336, y: -240)),
//        Square(position: CGPoint(x: -336, y: -144)),
//        Square(position: CGPoint(x: -336, y: -48)),
//        Square(position: CGPoint(x: -336, y: 48)),
//        Square(position: CGPoint(x: -336, y: 144)),
//        Square(position: CGPoint(x: -336, y: 240)),
//        Square(position: CGPoint(x: -336, y: 336))
//    ],
//    [//B
//        Square(position: CGPoint(x: -240, y: -336)),
//        Square(position: CGPoint(x: -240, y: -240)),
//        Square(position: CGPoint(x: -240, y: -144)),
//        Square(position: CGPoint(x: -240, y: -48)),
//        Square(position: CGPoint(x: -240, y: 48)),
//        Square(position: CGPoint(x: -240, y: 144)),
//        Square(position: CGPoint(x: -240, y: 240)),
//        Square(position: CGPoint(x: -240, y: 336))
//    ],
//    [//C
//        Square(position: CGPoint(x: -144, y: -336)),
//        Square(position: CGPoint(x: -144, y: -240)),
//        Square(position: CGPoint(x: -144, y: -144)),
//        Square(position: CGPoint(x: -144, y: -48)),
//        Square(position: CGPoint(x: -144, y: 48)),
//        Square(position: CGPoint(x: -144, y: 144)),
//        Square(position: CGPoint(x: -144, y: 240)),
//        Square(position: CGPoint(x: -144, y: 336))
//    ],
//    [//D
//        Square(position: CGPoint(x: -48, y: -336)),
//        Square(position: CGPoint(x: -48, y: -240)),
//        Square(position: CGPoint(x: -48, y: -144)),
//        Square(position: CGPoint(x: -48, y: -48)),
//        Square(position: CGPoint(x: -48, y: 48)),
//        Square(position: CGPoint(x: -48, y: 144)),
//        Square(position: CGPoint(x: -48, y: 240)),
//        Square(position: CGPoint(x: -48, y: 336))
//    ],
//    [//E
//        Square(position: CGPoint(x: 48, y: -336)),
//        Square(position: CGPoint(x: 48, y: -240)),
//        Square(position: CGPoint(x: 48, y: -144)),
//        Square(position: CGPoint(x: 48, y: -48)),
//        Square(position: CGPoint(x: 48, y: 48)),
//        Square(position: CGPoint(x: 48, y: 144)),
//        Square(position: CGPoint(x: 48, y: 240)),
//        Square(position: CGPoint(x: 48, y: 336))
//    ],
//    [//F
//        Square(position: CGPoint(x: 144, y: -336)),
//        Square(position: CGPoint(x: 144, y: -240)),
//        Square(position: CGPoint(x: 144, y: -144)),
//        Square(position: CGPoint(x: 144, y: -48)),
//        Square(position: CGPoint(x: 144, y: 48)),
//        Square(position: CGPoint(x: 144, y: 144)),
//        Square(position: CGPoint(x: 144, y: 240)),
//        Square(position: CGPoint(x: 144, y: 336))
//    ],
//    [//G
//        Square(position: CGPoint(x: 240, y: -336)),
//        Square(position: CGPoint(x: 240, y: -240)),
//        Square(position: CGPoint(x: 240, y: -144)),
//        Square(position: CGPoint(x: 240, y: -48)),
//        Square(position: CGPoint(x: 240, y: 48)),
//        Square(position: CGPoint(x: 240, y: 144)),
//        Square(position: CGPoint(x: 240, y: 240)),
//        Square(position: CGPoint(x: 240, y: 336))
//    ],
//    [//H
//        Square(position: CGPoint(x: 336, y: -336)),
//        Square(position: CGPoint(x: 336, y: -240)),
//        Square(position: CGPoint(x: 336, y: -144)),
//        Square(position: CGPoint(x: 336, y: -48)),
//        Square(position: CGPoint(x: 336, y: 48)),
//        Square(position: CGPoint(x: 336, y: 144)),
//        Square(position: CGPoint(x: 336, y: 240)),
//        Square(position: CGPoint(x: 336, y: 336))
//    ]
//]

