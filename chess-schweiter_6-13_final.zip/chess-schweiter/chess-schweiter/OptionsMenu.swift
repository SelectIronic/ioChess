//
//  OptionsMenu.swift
//  chess-schweiter
//
//  Created by SCHWEITER JOHN S on 4/13/16.
//  Copyright © 2016 example. All rights reserved.
//

import Foundation
import SpriteKit

class OptionsMenu: SKScene {
    
    var backButton : SKSpriteNode?
    var twoPlayerButton : SKSpriteNode?
    var vsAIButton : SKSpriteNode?
    var gameTypeSelectionBorder : SKSpriteNode?
    
    var gameType = 2
    
    override func didMoveToView(view: SKView) {
        backButton = self.childNodeWithName("BACK") as! SKSpriteNode!
        twoPlayerButton = self.childNodeWithName("TWOPLAYER") as! SKSpriteNode!
        vsAIButton = self.childNodeWithName("VSAI") as! SKSpriteNode!
        gameTypeSelectionBorder = self.childNodeWithName("gameTypeSelectionBorder") as! SKSpriteNode!
        
        if gameType == 2 {
            gameTypeSelectionBorder?.position.y = (twoPlayerButton?.position.y)! + 24
        } else if gameType == 1{
            gameTypeSelectionBorder?.position.y = (vsAIButton?.position.y)! + 24
        }
    }
    override func touchesBegan(touches: Set<UITouch>, withEvent event: UIEvent?) {
                for touch in touches {
                    let location = touch.locationInNode(self)
                    print(location.x, location.y)
                    print(nodeAtPoint(location).name)
                    if(nodeAtPoint(location) == backButton) {
                        print("backButton clicked")
                        let mainScene = MainMenu(fileNamed: "MainMenu")
                        mainScene?.scaleMode = .AspectFit
                        self.view?.presentScene(mainScene!, transition: SKTransition.pushWithDirection(SKTransitionDirection.Right, duration: 1))
                    }
                    if(nodeAtPoint(location) == twoPlayerButton) {
                        print("twoPlayerButton clicked")
                        gameType = 2
                        gameTypeSelectionBorder?.position.y = (twoPlayerButton?.position.y)! + 24
                    }
                    if(nodeAtPoint(location) == vsAIButton) {
                        print("vsAIButton clicked")
                        gameType = 1
                        gameTypeSelectionBorder?.position.y = (vsAIButton?.position.y)! + 24
                    }
                }
    }
}