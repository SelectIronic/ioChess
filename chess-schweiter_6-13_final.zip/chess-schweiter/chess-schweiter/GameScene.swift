//
//  GameScene.swift
//  chess-schweiter
//
//  Created by SCHWEITER JOHN S on 4/12/16.
//  Copyright (c) 2016 example. All rights reserved.
//

import SpriteKit

class GameScene: SKScene {
    
    var backButton : SKSpriteNode!
    
    var king_white : Piece!
    var queen_white : Piece!
    var bishop_white_right : Piece!
    var bishop_white_left : Piece!
    var knight_white_right : Piece!
    var knight_white_left : Piece!
    var rook_white_right : Piece!
    var rook_white_left : Piece!
    var pawn_white_a2 : Piece!
    var pawn_white_b2 : Piece!
    var pawn_white_c2 : Piece!
    var pawn_white_d2 : Piece!
    var pawn_white_e2 : Piece!
    var pawn_white_f2 : Piece!
    var pawn_white_g2 : Piece!
    var pawn_white_h2 : Piece!
    
    var whitePieces : Array<Piece>!
    
    var king_black : Piece!
    var queen_black : Piece!
    var bishop_black_right : Piece!
    var bishop_black_left : Piece!
    var knight_black_right : Piece!
    var knight_black_left : Piece!
    var rook_black_right : Piece!
    var rook_black_left : Piece!
    var pawn_black_a7 : Piece!
    var pawn_black_b7 : Piece!
    var pawn_black_c7 : Piece!
    var pawn_black_d7 : Piece!
    var pawn_black_e7 : Piece!
    var pawn_black_f7 : Piece!
    var pawn_black_g7 : Piece!
    var pawn_black_h7 : Piece!
    
    var blackPieces : Array<Piece>!
    
    var activePiece : Piece?
    
    var active_piece_highlight : SKSpriteNode!
    var white_turn_highlight : SKSpriteNode!
    var black_turn_highlight : SKSpriteNode!
    
    var white_turn = true
    
    var chessBoard : ChessBoard!
    
    var en_passantable : Piece?
    
    var promoting = false
    
    var whiteCheckmated = false
    var blackCheckmated = false
    var stalemate = false
    
    override func didMoveToView(view: SKView) {
        backButton = self.childNodeWithName("BACK_label") as! SKSpriteNode!
        
        chessBoard = ChessBoard()
        king_white = Piece(pieceType: "king", pieceColor: "white", position: CGPoint(x: 48, y: -336), myScene: self)
        queen_white = Piece(pieceType: "queen", pieceColor: "white", position: CGPoint(x: -48, y: -336), myScene: self)
        bishop_white_right = Piece(pieceType: "bishop", pieceColor: "white", position: CGPoint(x: 144, y: -336), myScene: self)
        bishop_white_left = Piece(pieceType: "bishop", pieceColor: "white", position: CGPoint(x: -144, y: -336), myScene: self)
        knight_white_right = Piece(pieceType: "knight", pieceColor: "white", position: CGPoint(x: 240, y: -336), myScene: self)
        knight_white_left = Piece(pieceType: "knight", pieceColor: "white", position: CGPoint(x: -240, y: -336), myScene: self)
        rook_white_right = Piece(pieceType: "rook", pieceColor: "white", position: CGPoint(x: 336, y: -336), myScene: self)
        rook_white_left = Piece(pieceType: "rook", pieceColor: "white", position: CGPoint(x: -336, y: -336), myScene: self)
        pawn_white_a2 = Piece(pieceType: "pawn", pieceColor: "white", position: CGPoint(x: -336, y: -240), myScene: self)
        pawn_white_b2 = Piece(pieceType: "pawn", pieceColor: "white", position: CGPoint(x: -240, y: -240), myScene: self)
        pawn_white_c2 = Piece(pieceType: "pawn", pieceColor: "white", position: CGPoint(x: -144, y: -240), myScene: self)
        pawn_white_d2 = Piece(pieceType: "pawn", pieceColor: "white", position: CGPoint(x: -48, y: -240), myScene: self)
        pawn_white_e2 = Piece(pieceType: "pawn", pieceColor: "white", position: CGPoint(x: 48, y: -240), myScene: self)
        pawn_white_f2 = Piece(pieceType: "pawn", pieceColor: "white", position: CGPoint(x: 144, y: -240), myScene: self)
        pawn_white_g2 = Piece(pieceType: "pawn", pieceColor: "white", position: CGPoint(x: 240, y: -240), myScene: self)
        pawn_white_h2 = Piece(pieceType: "pawn", pieceColor: "white", position: CGPoint(x: 336, y: -240), myScene: self)
        
        whitePieces = [king_white, queen_white, bishop_white_right, bishop_white_left, knight_white_right, knight_white_left, rook_white_right, rook_white_left, pawn_white_a2, pawn_white_b2, pawn_white_c2, pawn_white_d2, pawn_white_e2, pawn_white_f2, pawn_white_g2, pawn_white_h2]
        
        
        king_black = Piece(pieceType: "king", pieceColor: "black", position: CGPoint(x: 48, y: 336), myScene: self)
        queen_black = Piece(pieceType: "queen", pieceColor: "black", position: CGPoint(x: -48, y: 336), myScene: self)
        bishop_black_right = Piece(pieceType: "bishop", pieceColor: "black", position: CGPoint(x: 144, y: 336), myScene: self)
        bishop_black_left = Piece(pieceType: "bishop", pieceColor: "black", position: CGPoint(x: -144, y: 336), myScene: self)
        knight_black_right = Piece(pieceType: "knight", pieceColor: "black", position: CGPoint(x: 240, y: 336), myScene: self)
        knight_black_left = Piece(pieceType: "knight", pieceColor: "black", position: CGPoint(x: -240, y: 336), myScene: self)
        rook_black_right = Piece(pieceType: "rook", pieceColor: "black", position: CGPoint(x: 336, y: 336), myScene: self)
        rook_black_left = Piece(pieceType: "rook", pieceColor: "black", position: CGPoint(x: -336, y: 336), myScene: self)
        pawn_black_a7 = Piece(pieceType: "pawn", pieceColor: "black", position: CGPoint(x: -336, y: 240), myScene: self)
        pawn_black_b7 = Piece(pieceType: "pawn", pieceColor: "black", position: CGPoint(x: -240, y: 240), myScene: self)
        pawn_black_c7 = Piece(pieceType: "pawn", pieceColor: "black", position: CGPoint(x: -144, y: 240), myScene: self)
        pawn_black_d7 = Piece(pieceType: "pawn", pieceColor: "black", position: CGPoint(x: 48, y: 240), myScene: self)
        pawn_black_e7 = Piece(pieceType: "pawn", pieceColor: "black", position: CGPoint(x: -48, y: 240), myScene: self)
        pawn_black_f7 = Piece(pieceType: "pawn", pieceColor: "black", position: CGPoint(x: 144, y: 240), myScene: self)
        pawn_black_g7 = Piece(pieceType: "pawn", pieceColor: "black", position: CGPoint(x: 240, y: 240), myScene: self)
        pawn_black_h7 = Piece(pieceType: "pawn", pieceColor: "black", position: CGPoint(x: 336, y: 240), myScene: self)
        
        blackPieces = [king_black, queen_black, bishop_black_right, bishop_black_left, knight_black_right, knight_black_left, rook_black_right, rook_black_left, pawn_black_a7, pawn_black_b7, pawn_black_c7, pawn_black_d7, pawn_black_e7, pawn_black_f7, pawn_black_g7, pawn_black_h7]
        
        
        white_turn_highlight = self.childNodeWithName("WHITETURN_HIGHLIGHT") as! SKSpriteNode!
        black_turn_highlight = self.childNodeWithName("BLACKTURN_HIGHLIGHT") as! SKSpriteNode!
        active_piece_highlight = self.childNodeWithName("ACTIVE_PIECE_HIGHLIGHT") as! SKSpriteNode!
        
        for piece in blackPieces { piece.setAvailableMoves() }
        for piece in whitePieces { piece.setAvailableMoves() }
        
        updateBoard()
        white_turn = true
        //print(self.children)
    }
    
    
    func updateBoard() {
        for file in chessBoard.squares {
            for square in file {
                square.piece = nil
                if let piece = nodeAtPoint(square.position) as? Piece {
                    square.piece = piece
                }
            }
        }
    }
    
    func updateMoves() {
        for piece in blackPieces {
            piece.availableMoves.removeAll()
            piece.piecesWhichProtect.removeAll()
            piece.piecesWhichCheck.removeAll()
        }
        for piece in whitePieces {
            piece.availableMoves.removeAll()
            piece.piecesWhichProtect.removeAll()
            piece.piecesWhichCheck.removeAll()
        }
        
        //set castle_kingside
        //these if let blocks are a somewhat convoluted way of simply asking:
        //if there are no pieces on either of these squares{}
        if let _ = nodeAtPoint(CGPoint(x: 240, y: 336)) as? Piece{
        } else {
            if let _ = nodeAtPoint(CGPoint(x: 144, y: 336)) as? Piece{
            } else {
                if !king_black.hasMoved && nodeAtPoint(CGPoint(x: 336, y: 336)) == rook_black_right && !rook_black_right.hasMoved {
                    king_black.availableMoves.append(CGPoint(x: 240, y: 336))
                }
            }
        }
        if let _ = nodeAtPoint(CGPoint(x: 240, y: -336)) as? Piece{
        } else {
            if let _ = nodeAtPoint(CGPoint(x: 144, y: -336)) as? Piece{
            } else {
                if !king_white.hasMoved && nodeAtPoint(CGPoint(x: 336, y: -336)) == rook_white_right && !rook_white_right.hasMoved {
                    king_white.availableMoves.append(CGPoint(x: 240, y: -336))
                }
            }
        }
        //end set castle_kingside
        
        //set en_passanters
        if en_passantable != nil {
            let forward = en_passantable?.pieceColor == "white" ? 1 : -1
            if let piece = nodeAtPoint(CGPoint(x: (en_passantable?.position.x)! - 96, y: (en_passantable?.position.y)!)) as? Piece {
                if piece.pieceType == "pawn" && piece.pieceColor != en_passantable?.pieceColor {
                    piece.availableMoves.append(CGPoint(x: (en_passantable?.position.x)!, y: (en_passantable?.position.y)! - CGFloat(96 * forward)))
                }
            }
            if let piece = nodeAtPoint(CGPoint(x: (en_passantable?.position.x)! + 96, y: (en_passantable?.position.y)!)) as? Piece {
                if piece.pieceType == "pawn" && piece.pieceColor != en_passantable?.pieceColor {
                    piece.availableMoves.append(CGPoint(x: (en_passantable?.position.x)!, y: (en_passantable?.position.y)! - CGFloat(96 * forward)))
                }
            }
        }
        //end set en_passanters
        blackCheckmated = true
        for black_piece in blackPieces {
            black_piece.setAvailableMoves()
            for black_move in black_piece.availableMoves {
                //print(black_piece.position)
                if black_piece.pieceType == "king" && black_move.x == 240 && black_piece.position.x == 96 {
                    if chessBoard.canMove(black_piece.position, destination: black_move, special: "castle_kingside") {
                        blackCheckmated = false
                    }
                } else {
                    if black_piece.pieceType == "pawn" && black_move.x != black_piece.position.x && nodeAtPoint(CGPoint(x: black_move.x, y: black_piece.position.y)) == en_passantable {
                        if chessBoard.canMove(black_piece.position, destination: black_move, special: "en_passant") {
                            blackCheckmated = false
                        }
                    } else {
                        if chessBoard.canMove(black_piece.position, destination: black_move, special: nil) {
                            blackCheckmated = false
                        }
                    }
                }
            }
        }
        whiteCheckmated = true
        for white_piece in whitePieces {
            white_piece.setAvailableMoves()
            for white_move in white_piece.availableMoves {
                if white_piece.pieceType == "king" && white_move.x == 240 && white_piece.position.x == 96 {
                    if chessBoard.canMove(white_piece.position, destination: white_move, special: "castle_kingside") {
                        whiteCheckmated = false
                    }
                } else {
                    if white_piece.pieceType == "pawn" && white_move.x != white_piece.position.x && nodeAtPoint(CGPoint(x: white_move.x, y: white_piece.position.y)) == en_passantable {
                        if chessBoard.canMove(white_piece.position, destination: white_move, special: "en_passant") {
                            whiteCheckmated = false
                        }
                    } else {
                        if chessBoard.canMove(white_piece.position, destination: white_move, special: nil) {
                            whiteCheckmated = false
                        }
                    }
                }
            }
        }
        if whiteCheckmated && king_white.piecesWhichCheck.count == 0 {
            whiteCheckmated = false
            stalemate = true
        }
        if blackCheckmated && king_black.piecesWhichCheck.count == 0 {
            blackCheckmated = false
            stalemate = true
        }
    }
    
    func runWhiteTurn(square : CGPoint, special: String?) {
        if activePiece!.pieceCanMoveToSquare(square) && chessBoard.canMove(activePiece!.position, destination: square, special: special) {
            
            if special == "promotion" {
                makePawnPromotionMenu()
            }
            
            if let thisPiece = nodeAtPoint(square) as? Piece {
                if thisPiece.pieceColor == "black" { thisPiece.runAction(SKAction.removeFromParent()) }
                var i = 0
                for piece in blackPieces {
                    if piece == thisPiece {
                        blackPieces.removeAtIndex(i)
                    }
                    i += 1
                }
            }
            
            //remove en_passantable
            if en_passantable != nil && en_passantable?.position.y == square.y - 96 && activePiece!.pieceType == "pawn" {
                en_passantable!.runAction(SKAction.removeFromParent())
                var i = 0
                for piece in blackPieces {
                    if piece == en_passantable {
                        blackPieces.removeAtIndex(i)
                    }
                    i += 1
                }
            }
            //end remove en_passantable
            //set en_passantable
            if activePiece!.position.y == -240 && square.y == -48 && activePiece!.pieceType == "pawn" {
                en_passantable = activePiece
            } else {
                en_passantable = nil
            }
            //end set en_passantable
            
            if special == "castle_kingside" {
                rook_white_right.runAction(SKAction.moveTo(CGPoint(x: 144, y: -336), duration: 0.5))
                rook_white_right.hasMoved = true
            }
            activePiece!.self.runAction(SKAction.moveTo(square, duration: 0.5)) {
                self.updateBoard()
                self.updateMoves()
                self.checkForCheck()
            }
            activePiece!.hasMoved = true
            
//            updateBoard()
            active_piece_highlight.position = CGPoint(x: 672, y: 144)
            white_turn = false
            white_turn_highlight.runAction(SKAction.moveTo(CGPoint(x: -576, y: -192), duration: 0.5))
            black_turn_highlight.runAction(SKAction.moveTo(CGPoint(x: 480, y: 192), duration: 0.5))
//            for piece in blackPieces { piece.setAvailableMoves() }
//            for piece in whitePieces { piece.setAvailableMoves() }
//            updateBoard()
//            updateMoves()
//            checkForCheck()
        }
    }
    func runBlackTurn(square : CGPoint, special: String?) {
        if activePiece!.pieceCanMoveToSquare(square) && chessBoard.canMove(activePiece!.position, destination: square, special: special) {
            
            if special == "promotion" {
                makePawnPromotionMenu()
            }
            
            if let thisPiece = nodeAtPoint(square) as? Piece {
                if thisPiece.pieceColor == "white" { thisPiece.runAction(SKAction.removeFromParent()) }
                var i = 0
                for piece in whitePieces {
                    if piece == thisPiece {
                        whitePieces.removeAtIndex(i)
                    }
                    i += 1
                }
            }
            
            //remove en_passantable
            if en_passantable != nil && en_passantable?.position.y == square.y + 96 && activePiece!.pieceType == "pawn" {
                en_passantable!.runAction(SKAction.removeFromParent())
                var i = 0
                for piece in whitePieces {
                    if piece == en_passantable {
                        whitePieces.removeAtIndex(i)
                    }
                    i += 1
                }
            }
            //end remove en_passantable
            //set en_passantable
            if activePiece!.position.y == 240 && square.y == 48 && activePiece!.pieceType == "pawn" {
                en_passantable = activePiece
            } else {
                en_passantable = nil
            }
            //end set en_passantable
            
            if special == "castle_kingside" {
                rook_black_right.runAction(SKAction.moveTo(CGPoint(x: 144, y: 336), duration: 0.5))
                rook_black_right.hasMoved = true
            }
            activePiece!.self.runAction(SKAction.moveTo(square, duration: 0.5)) {
                self.updateBoard()
                self.updateMoves()
                self.checkForCheck()
            }
            activePiece!.hasMoved = true
            
//            updateBoard()
            active_piece_highlight.position = CGPoint(x: 672, y: 144)
            white_turn = true
            white_turn_highlight.runAction(SKAction.moveTo(CGPoint(x: -480, y: -192), duration: 0.5))
            black_turn_highlight.runAction(SKAction.moveTo(CGPoint(x: 576, y: 192), duration: 0.5))
//            for piece in blackPieces { piece.setAvailableMoves() }
//            for piece in whitePieces { piece.setAvailableMoves() }
//            updateBoard()
//            updateMoves()
//            checkForCheck()
        }
    }
    
    func makePawnPromotionMenu() {
        let grey_panel = SKSpriteNode(imageNamed: "button_grey")
        grey_panel.name = "grey_panel"
        grey_panel.position = CGPoint(x: 0,y: 0)
        grey_panel.zPosition = 100
        self.addChild(grey_panel)
        
        let prom_piece_color = white_turn == true ? "white" : "black"
        
        let prom_queen = SKSpriteNode(imageNamed: "queen_\(prom_piece_color)")
        prom_queen.name = "prom_queen"
        prom_queen.position = CGPoint(x: -144,y: 0)
        prom_queen.zPosition = 101
        self.addChild(prom_queen)
        
        let prom_knight = SKSpriteNode(imageNamed: "knight_\(prom_piece_color)")
        prom_knight.name = "prom_knight"
        prom_knight.position = CGPoint(x: -48,y: 0)
        prom_knight.zPosition = 101
        self.addChild(prom_knight)
        
        let prom_rook = SKSpriteNode(imageNamed: "rook_\(prom_piece_color)")
        prom_rook.name = "prom_rook"
        prom_rook.position = CGPoint(x: 48,y: 0)
        prom_rook.zPosition = 101
        self.addChild(prom_rook)
        
        let prom_bishop = SKSpriteNode(imageNamed: "bishop_\(prom_piece_color)")
        prom_bishop.name = "prom_bishop"
        prom_bishop.position = CGPoint(x: 144,y: 0)
        prom_bishop.zPosition = 101
        self.addChild(prom_bishop)
        
        promoting = true
    }
    
    override func touchesBegan(touches: Set<UITouch>, withEvent event: UIEvent?) {
        /* Called when a touch begins */
        
        for touch in touches {
            let location = touch.locationInNode(self)
            //print(nodesAtPoint(location))
            
            if let spriteNode = nodeAtPoint(location) as? SKSpriteNode {
                //print(spriteNode.name)
                
                if(spriteNode == backButton!) {
                    print("backButton clicked")
                    let mainScene = MainMenu(fileNamed: "MainMenu")
                    mainScene?.scaleMode = .AspectFit
                    self.view?.presentScene(mainScene!, transition: SKTransition.pushWithDirection(SKTransitionDirection.Right, duration: 1))
                } else {
                    if !whiteCheckmated && !blackCheckmated && !stalemate {
                        if promoting == true {
                            let grey_panel = self.childNodeWithName("grey_panel")
                            let prom_queen = self.childNodeWithName("prom_queen")
                            let prom_knight = self.childNodeWithName("prom_knight")
                            let prom_rook = self.childNodeWithName("prom_rook")
                            let prom_bishop = self.childNodeWithName("prom_bishop")
                            
                            if spriteNode == prom_queen || spriteNode == prom_knight || spriteNode == prom_rook || spriteNode == prom_bishop {
                                switch spriteNode {
                                case prom_queen!:
                                    activePiece!.pieceType = "queen"
                                case prom_knight!:
                                    activePiece!.pieceType = "knight"
                                case prom_rook!:
                                    activePiece!.pieceType = "rook"
                                case prom_bishop!:
                                    activePiece!.pieceType = "bishop"
                                default:
                                    print("How did you get in here?")
                                }
                                activePiece!.texture = SKTexture(imageNamed: "\(activePiece!.pieceType)_\(activePiece!.pieceColor)")
                                prom_queen!.runAction(SKAction.removeFromParent())
                                prom_knight!.runAction(SKAction.removeFromParent())
                                prom_rook!.runAction(SKAction.removeFromParent())
                                prom_bishop!.runAction(SKAction.removeFromParent())
                                grey_panel!.runAction(SKAction.removeFromParent())
                                promoting = false
                            }
                            
                        } else {
                            
                            //"snap" the touch location to the center of the square which contains it
                            var square = CGPoint()
                            square.x = location.x
                            square.y = location.y
                            square.x -= square.x >= 0 ? (square.x % 96) - 48 : (square.x % -96) + 48
                            square.y -= square.y >= 0 ? (square.y % 96) - 48 : (square.y % -96) + 48
                            
                            updateBoard()
                            updateMoves()
                            
                            
                            
                            //print(activePiece)
                            if white_turn {
                                if activePiece != nil && activePiece?.pieceColor == "black" { activePiece = nil }
                                if activePiece != nil && activePiece?.pieceColor == "white" {
                                    if let thisPiece = spriteNode as? Piece {
                                        if thisPiece.pieceColor == "white" {
                                            activePiece = thisPiece
                                            active_piece_highlight?.position = (activePiece?.position)!
                                        } else {
                                            if activePiece?.pieceType == "pawn" && square.y == 336{
                                                runWhiteTurn(square, special: "promotion")
                                            } else {
                                                runWhiteTurn(square, special: nil)
                                            }
                                        }
                                    } else {
                                        if activePiece!.pieceType == "king" && !activePiece!.hasMoved && square == CGPoint(x: 240, y: -336) && nodeAtPoint(CGPoint(x: 336, y: -336)) == rook_white_right && !rook_white_right.hasMoved {
                                            runWhiteTurn(square, special: "castle_kingside")
                                        } else {
                                            if activePiece?.pieceType == "pawn" {
                                                if square.y == 336{
                                                    runWhiteTurn(square, special: "promotion")
                                                } else {
                                                    if en_passantable != nil && square.x == (en_passantable?.position.x)! && square.y == (en_passantable?.position.y)! + 96 {
                                                        runWhiteTurn(square, special: "en_passant")
                                                    } else {
                                                        runWhiteTurn(square, special: nil)
                                                    }
                                                }
                                            } else {
                                                runWhiteTurn(square, special: nil)
                                            }
                                        }
                                    }
                                    
                                }
                                if activePiece == nil {
                                    if let thisPiece = spriteNode as? Piece {
                                        if thisPiece.pieceColor == "white" {
                                            activePiece = thisPiece
                                            active_piece_highlight.position = (activePiece?.position)!
                                        }
                                    }
                                }
                                //print(activePiece)
                            } else {
                                //black_turn
                                if activePiece != nil && activePiece?.pieceColor == "white" { activePiece = nil }
                                if activePiece != nil && activePiece?.pieceColor == "black" {
                                    if let thisPiece = spriteNode as? Piece {
                                        if thisPiece.pieceColor == "black" {
                                            activePiece = thisPiece
                                            active_piece_highlight?.position = (activePiece?.position)!
                                        } else {
                                            if activePiece?.pieceType == "pawn" && square.y == -336{
                                                runBlackTurn(square, special: "promotion")
                                            } else {
                                                runBlackTurn(square, special: nil)
                                            }
                                        }
                                    } else {
                                        if activePiece!.pieceType == "king" && !activePiece!.hasMoved && square == CGPoint(x: 240, y: 336) && nodeAtPoint(CGPoint(x: 336, y: 336)) == rook_black_right && !rook_black_right.hasMoved {
                                            runBlackTurn(square, special: "castle_kingside")
                                        } else {
                                            if activePiece?.pieceType == "pawn" {
                                                if square.y == -336{
                                                    runBlackTurn(square, special: "promotion")
                                                } else {
                                                    if en_passantable != nil && square.x == (en_passantable?.position.x)! && square.y == (en_passantable?.position.y)! - 96 {
                                                        runBlackTurn(square, special: "en_passant")
                                                    } else {
                                                        runBlackTurn(square, special: nil)
                                                    }
                                                }
                                            } else {
                                                runBlackTurn(square, special: nil)
                                            }
                                        }
                                    }
                                    
                                }
                                if activePiece == nil {
                                    if let thisPiece = spriteNode as? Piece {
                                        if thisPiece.pieceColor == "black" {
                                            activePiece = thisPiece
                                            active_piece_highlight.position = (activePiece?.position)!
                                        }
                                    }
                                }
                                print(activePiece)
                            }
                        }
                        //end promoting check
                    }
                    
                }//END EVERYTHING BUT BACK BUTTON
            }
        }
    }
    
    func checkForCheck() {
        //TODO: CHECK FOR MATE && USE LABEL SPRITES
        //On-Screen : 480, Off-Screen : 576, if white *= -1
        //print(activePiece!.position)
        let checkBlackSprite = self.childNodeWithName("CHECK_BLACK") as! SKSpriteNode!
        let mateBlackSprite = self.childNodeWithName("MATE_BLACK") as! SKSpriteNode!
        let staleBlackSprite = self.childNodeWithName("STALE_BLACK") as! SKSpriteNode!
        
        let checkWhiteSprite = self.childNodeWithName("CHECK_WHITE") as! SKSpriteNode!
        let mateWhiteSprite = self.childNodeWithName("MATE_WHITE") as! SKSpriteNode!
        let staleWhiteSprite = self.childNodeWithName("STALE_WHITE") as! SKSpriteNode!
        if stalemate == true {
            //STALEMATE
            print("STALEMATE")
            checkBlackSprite.runAction(SKAction.moveToX(576, duration: 0.5))
            checkWhiteSprite.runAction(SKAction.moveToX(-576, duration: 0.5))
            
            staleBlackSprite.runAction(SKAction.moveToX(480, duration: 0.5))
            mateBlackSprite.runAction(SKAction.moveToX(480, duration: 0.5))
            staleWhiteSprite.runAction(SKAction.moveToX(-480, duration: 0.5))
            mateWhiteSprite.runAction(SKAction.moveToX(-480, duration: 0.5))
        } else {
            staleBlackSprite.runAction(SKAction.moveToX(576, duration: 0.5))
            staleWhiteSprite.runAction(SKAction.moveToX(-576, duration: 0.5))
        }
        if king_white.piecesWhichCheck.count > 0 {
            //CHECK
            print("CHECK")
            checkWhiteSprite.runAction(SKAction.moveToX(-480, duration: 0.5))
            if whiteCheckmated {
                //MATE
                print("MATE")
                mateWhiteSprite.runAction(SKAction.moveToX(-480, duration: 0.5))
            }
        } else {
            checkWhiteSprite.runAction(SKAction.moveToX(-576, duration: 0.5))
            if !stalemate { mateWhiteSprite.runAction(SKAction.moveToX(-576, duration: 0.5)) }
        }
        if king_black.piecesWhichCheck.count > 0 {
            //CHECK
            print("CHECK")
            checkBlackSprite.runAction(SKAction.moveToX(480, duration: 0.5))
            if blackCheckmated {
                //MATE
                print("MATE")
                mateBlackSprite.runAction(SKAction.moveToX(480, duration: 0.5))
            }
        } else {
            checkBlackSprite.runAction(SKAction.moveToX(576, duration: 0.5))
            if !stalemate { mateBlackSprite.runAction(SKAction.moveToX(576, duration: 0.5)) }
        }
    }
    
    override func update(currentTime: CFTimeInterval) {
        /* Called before each frame is rendered */
    }
}
